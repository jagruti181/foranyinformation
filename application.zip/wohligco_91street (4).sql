-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2014 at 11:33 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wohligco_91street`
--
CREATE DATABASE IF NOT EXISTS `wohligco_91street` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `wohligco_91street`;

-- --------------------------------------------------------

--
-- Table structure for table `accesslevel`
--

CREATE TABLE IF NOT EXISTS `accesslevel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `accesslevel`
--

INSERT INTO `accesslevel` (`id`, `name`) VALUES
(1, 'admin'),
(3, 'customer'),
(2, 'organizer');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `pricerange` int(11) NOT NULL,
  `video` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `facebookpage` varchar(255) NOT NULL,
  `twitterpage` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `name`, `pricerange`, `video`, `description`, `website`, `facebookpage`, `twitterpage`, `logo`) VALUES
(1, 'Nike', 1, 'https://www.youtube.com/watch?v=9hRNFgSLLAQ', 'ddd', 'website', 'fbpage', 'twpage', 'nikelogo'),
(2, 'Woodland', 2, 'https://www.youtube.com/watch?v=9hRNFgSLLAQ', '', '', '', '', ''),
(3, 'Adidas', 3, 'https://www.youtube.com/watch?v=9hRNFgSLLAQ', 'a', 'web', 'fb', 'tw', 'logo'),
(31, 'Reebok', 0, '', '', '', '', '', ''),
(32, 'abcd2', 0, '', '', '', '', '', ''),
(33, 'demo9', 0, '', '', '', '', '', ''),
(34, 'test', 0, '', '', '', '', '', ''),
(35, 'bbbbbbbbbb', 0, '', '', '', '', '', ''),
(36, 'aaaaaaaaaa', 0, '', '', '', '', '', ''),
(37, 'aaaaaaaaaa', 0, '', '', '', '', '', ''),
(38, 'pepe jeans', 0, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `brandcategory`
--

CREATE TABLE IF NOT EXISTS `brandcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brandid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=195 ;

--
-- Dumping data for table `brandcategory`
--

INSERT INTO `brandcategory` (`id`, `brandid`, `categoryid`) VALUES
(1, 1, 1),
(3, 1, 4),
(4, 1, 5),
(5, 1, 6),
(6, 3, 4),
(7, 2, 5),
(8, 16, 4),
(9, 16, 9),
(10, 16, 11),
(11, 16, 5),
(12, 16, 6),
(13, 16, 12),
(14, 16, 13),
(15, 3, 4),
(16, 3, 9),
(17, 3, 11),
(18, 3, 5),
(19, 3, 6),
(20, 18, 4),
(21, 18, 9),
(22, 18, 4),
(23, 18, 9),
(24, 18, 11),
(25, 18, 5),
(26, 18, 6),
(27, 3, 4),
(28, 3, 9),
(29, 3, 11),
(30, 3, 5),
(31, 3, 6),
(32, 3, 4),
(33, 3, 9),
(34, 3, 11),
(35, 3, 5),
(36, 3, 6),
(37, 3, 10),
(38, 30, 4),
(39, 30, 9),
(40, 30, 10),
(41, 30, 11),
(42, 30, 5),
(43, 30, 6),
(44, 31, 4),
(45, 31, 5),
(46, 31, 6),
(47, 31, 12),
(48, 32, 4),
(49, 32, 9),
(50, 32, 11),
(51, 32, 5),
(52, 32, 12),
(53, 32, 13),
(54, 32, 14),
(55, 32, 10),
(56, 32, 19),
(57, 32, 6),
(58, 32, 15),
(59, 33, 4),
(60, 33, 10),
(61, 33, 12),
(62, 33, 14),
(63, 34, 4),
(64, 34, 10),
(65, 34, 11),
(66, 34, 5),
(67, 34, 19),
(68, 34, 6),
(69, 34, 12),
(70, 34, 14),
(71, 34, 15),
(143, 35, 35),
(144, 35, 4),
(145, 35, 10),
(146, 35, 11),
(147, 35, 17),
(148, 35, 5),
(149, 35, 19),
(150, 35, 6),
(151, 35, 12),
(152, 35, 13),
(153, 35, 14),
(169, 36, 36),
(170, 36, 4),
(171, 36, 10),
(172, 36, 17),
(173, 36, 5),
(174, 36, 19),
(175, 36, 12),
(176, 36, 15),
(186, 38, 38),
(187, 38, 4),
(188, 38, 9),
(189, 38, 10),
(190, 38, 5),
(191, 38, 19),
(192, 38, 12),
(193, 38, 14),
(194, 38, 15);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `parent`, `status`) VALUES
(4, 'clothing', 0, 1),
(5, 'footwear', 0, 1),
(6, 'Fassion Accessories', 0, 1),
(9, 'casual', 4, 0),
(10, 'formals', 4, 0),
(11, 'party wear', 4, 0),
(12, 'Electronics', 0, 0),
(13, 'phones', 12, 0),
(14, 'TV', 12, 0),
(15, 'AC', 12, 0),
(17, 'Sports', 4, 0),
(18, 'Men', 4, 1),
(19, 'Men', 5, 1),
(20, 'main', 0, 1),
(21, 'sub', 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categorysubcategory`
--

CREATE TABLE IF NOT EXISTS `categorysubcategory` (
  `brandcategoryid` int(11) NOT NULL,
  `subcategoryid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorysubcategory`
--

INSERT INTO `categorysubcategory` (`brandcategoryid`, `subcategoryid`) VALUES
(4, 1),
(4, 2),
(1, 2),
(3, 1),
(3, 3),
(6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `name`) VALUES
(1, 'Mumbai'),
(2, 'pune'),
(4, 'Chennai1');

-- --------------------------------------------------------

--
-- Table structure for table `eventlog`
--

CREATE TABLE IF NOT EXISTS `eventlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `eventlog`
--

INSERT INTO `eventlog` (`id`, `event`, `user`, `description`, `timestamp`) VALUES
(1, 1, 1, 'Event Created', '2014-05-12 10:46:24'),
(2, 1, 1, 'Event Edited', '2014-05-12 10:47:43'),
(3, 1, 1, 'Event Category ,Topic updated', '2014-05-12 11:16:19'),
(4, 1, 1, 'Event Category ,Topic updated', '2014-05-12 11:16:51'),
(5, 3, 3, 'Event Edited', '2014-08-08 08:45:13'),
(6, 3, 3, 'Mall Edited', '2014-08-08 08:47:08'),
(7, 3, 3, 'Mall Edited', '2014-08-08 08:47:32'),
(8, 3, 3, 'Mall Edited', '2014-08-08 08:52:55'),
(9, 3, 3, 'City Edited', '2014-08-08 10:00:26'),
(10, 3, 3, 'City Edited', '2014-08-08 10:01:10'),
(11, 4, 4, 'City Edited', '2014-08-08 10:03:23'),
(12, 8, 8, 'City Edited', '2014-08-09 05:28:14'),
(13, 8, 8, 'Location Edited', '2014-08-09 05:30:25'),
(14, 4, 4, 'Location Edited', '2014-08-09 05:30:40'),
(15, 11, 11, 'Location Edited', '2014-08-09 05:49:23'),
(16, 8, 8, 'Location Edited', '2014-08-09 05:50:01'),
(17, 3, 3, 'Brand Edited', '2014-08-09 06:32:06'),
(18, 3, 3, 'Brand Edited', '2014-08-09 06:32:26'),
(19, 3, 3, 'Brand Edited', '2014-08-09 09:57:03'),
(20, 8, 8, 'Location Edited', '2014-08-11 05:14:59'),
(21, 1, 1, 'Mall Edited', '2014-08-11 09:52:00'),
(22, 32, 32, 'Brand Edited', '2014-08-19 05:28:20'),
(23, 32, 32, 'Brand Edited', '2014-08-19 05:28:55'),
(24, 1, 1, 'City Edited', '2014-08-21 08:34:32'),
(25, 12, 12, 'Location Edited', '2014-08-21 08:36:11'),
(26, 2, 2, 'Mall Edited', '2014-08-21 10:40:28'),
(27, 2, 2, 'Mall Edited', '2014-08-21 10:40:59'),
(28, 4, 4, 'Mall Edited', '2014-08-21 11:45:56'),
(29, 4, 4, 'Mall Edited', '2014-08-21 11:46:36'),
(30, 4, 4, 'Mall Edited', '2014-08-21 11:47:39'),
(31, 4, 4, 'Mall Edited', '2014-08-21 11:47:55'),
(32, 4, 4, 'Mall Edited', '2014-08-21 11:48:19'),
(33, 13, 13, 'Location Edited', '2014-08-21 12:12:46'),
(34, 13, 13, 'Location Edited', '2014-08-21 12:13:09'),
(35, 8, 8, 'Location Edited', '2014-08-22 05:52:40');

-- --------------------------------------------------------

--
-- Table structure for table `floor`
--

CREATE TABLE IF NOT EXISTS `floor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floorno` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `floor`
--

INSERT INTO `floor` (`id`, `floorno`) VALUES
(1, '1st'),
(2, '2nd'),
(3, '3rd'),
(4, '4th'),
(5, '5th'),
(6, '6th');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cityid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pincode` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `cityid`, `name`, `pincode`) VALUES
(1, 4, 'east', 0),
(2, 2, 'west', 0),
(4, 4, 'avi1', 0),
(7, 4, 'demo', 0),
(8, 4, 'abcdef', 0),
(9, 2, 'abcdefg', 0),
(10, 4, 'bandra', 0),
(11, 1, 'Dadar1', 0),
(12, 1, 'Ghatkopar (west)', 0),
(13, 4, 'test123', 410200);

-- --------------------------------------------------------

--
-- Table structure for table `mall`
--

CREATE TABLE IF NOT EXISTS `mall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `location` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `contactno` varchar(255) NOT NULL,
  `parkingfacility` varchar(255) NOT NULL,
  `cinema` varchar(255) NOT NULL,
  `cinemaoffer` varchar(255) NOT NULL,
  `restaurant` varchar(255) NOT NULL,
  `entertainment` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `specialoffers` text NOT NULL,
  `events` text NOT NULL,
  `facebookpage` varchar(255) NOT NULL,
  `pininterest` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `twitterpage` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mall`
--

INSERT INTO `mall` (`id`, `name`, `address`, `location`, `latitude`, `longitude`, `contactno`, `parkingfacility`, `cinema`, `cinemaoffer`, `restaurant`, `entertainment`, `website`, `email`, `logo`, `description`, `specialoffers`, `events`, `facebookpage`, `pininterest`, `instagram`, `twitterpage`) VALUES
(1, 'demo', 'demo', 2, 12.11, 13.23, '8989898989', 'both 2 wheeler and 4 wheeler parking', 'multiplex', '', 'demo', 'demo', 'wohlig.com', 'demo@demo.com', 'boy.png', 'demo', 'demoso', 'demoevent', '', '', '', ''),
(2, 'test', 'testaddress', 11, 12, 13, '9898989898', 'test', 'test', '', 'test', 'test', 'demo.com', 'pratik@wohlig.com', '011.jpg', 'testdesc', 'testoffer', 'testevent', '', '', '', ''),
(3, 'test2', 'test2', 1, 12, 13, '7878787878', 'test2', 'test2', 'test2', 'test2', 'test2', 'vtest2', 'notice@gmail.com', '013.jpg', 'test2', 'test2', 'test2', 'test2', '', '', ''),
(4, 'wwf', 'asc', 10, 12, 12, '13123', 'fwef', 'wef', '0', 'wfe', 'wef', 'kreativedsign.net', 'prshntgadge@gmail.com', 'images.jpg', 'acas', 'asc', 'asc', 'sasas', 'efw', 'ewfwe', 'efw');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `linktype` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `isactive` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `description`, `keyword`, `url`, `linktype`, `parent`, `isactive`, `order`, `icon`) VALUES
(1, 'Users', '', '', 'site/viewusers', 1, 0, 1, 1, 'icon-user'),
(2, 'Malls', '', '', 'site/viewmall', 1, 0, 1, 2, ' icon-calendar'),
(3, 'City', '', '', 'site/viewcity', 1, 0, 1, 3, ' icon-user-md'),
(4, 'Dashboard', '', '', 'site/index', 1, 0, 1, 0, 'icon-dashboard'),
(5, 'Brand', '', '', 'site/viewbrand', 1, 0, 1, 4, ' icon-ticket'),
(6, 'Store', '', '', '', 1, 0, 1, 5, 'icon-money'),
(7, 'Category', '', '', 'site/viewcategory', 1, 0, 1, 6, 'icon-book'),
(8, 'Store in Mall', '', '', 'site/viewstoreinmall', 1, 6, 1, 7, ' icon-file-text-alt'),
(9, 'Individual Store', '', '', 'site/viewindividualstore', 1, 6, 1, 8, ' icon-list-alt'),
(10, 'Offers', '', '', 'site/viewoffer', 1, 0, 1, 9, 'icon-user');

-- --------------------------------------------------------

--
-- Table structure for table `menuaccess`
--

CREATE TABLE IF NOT EXISTS `menuaccess` (
  `menu` int(11) NOT NULL,
  `access` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menuaccess`
--

INSERT INTO `menuaccess` (`menu`, `access`) VALUES
(1, 1),
(4, 1),
(2, 1),
(3, 1),
(5, 1),
(6, 1),
(7, 1),
(7, 3),
(8, 1),
(9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `header` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `header`, `description`, `from`, `to`) VALUES
(3, 'basic', '10% off', '2014-02-10', '2014-08-30'),
(4, 'demo', 'demo', '1970-01-01', '2014-08-16'),
(5, 'demotest', 'demodesc', '1970-01-01', '2014-08-22');

-- --------------------------------------------------------

--
-- Table structure for table `pricerange`
--

CREATE TABLE IF NOT EXISTS `pricerange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pricerange`
--

INSERT INTO `pricerange` (`id`, `range`) VALUES
(1, 'Very Low'),
(2, 'Low'),
(3, 'Moderate'),
(4, 'Expensive'),
(5, 'Very expensive');

-- --------------------------------------------------------

--
-- Table structure for table `shopclosed`
--

CREATE TABLE IF NOT EXISTS `shopclosed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `shopclosed`
--

INSERT INTO `shopclosed` (`id`, `day`) VALUES
(1, 'Sunday'),
(2, 'Monday'),
(4, 'Tuesday'),
(5, 'Wednesday'),
(6, 'Thursday'),
(7, 'Friday'),
(8, 'Saturday');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE IF NOT EXISTS `store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `city` int(11) NOT NULL,
  `brand` int(11) NOT NULL,
  `format` int(11) NOT NULL,
  `mall` int(11) NOT NULL,
  `floor` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `location` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` int(11) NOT NULL,
  `contactno` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `offer` int(11) NOT NULL,
  `workinghours` varchar(255) NOT NULL,
  `shopclosedon` int(11) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `name`, `city`, `brand`, `format`, `mall`, `floor`, `address`, `location`, `latitude`, `longitude`, `contactno`, `email`, `offer`, `workinghours`, `shopclosedon`, `description`) VALUES
(1, 'sporties', 4, 1, 1, 1, 2, 'demostoreaddress', 3, 12.11, 13, '2147483647', 'avinash@gmail.com', 1, '', 1, ''),
(4, 'demo5', 1, 1, 2, 0, 0, 'wadala road mumbai', 2, 12, 13, '9898989898', 'demo5@demo.com', 3, '', 1, ''),
(5, 'demo', 4, 2, 1, 1, 5, '', 0, 0, 0, '9090909090', 'demo@email.com', 3, '', 3, ''),
(6, 'Abcd', 2, 2, 1, 1, 2, '', 0, 0, 0, '1234', 'demo@email.com', 4, '', 6, ''),
(7, 'individual', 2, 31, 2, 0, 0, 'ahhcbjhc', 9, 12, 13, '9090909090', 'pratik@wohlig.com', 4, '', 6, ''),
(8, 'test', 2, 2, 2, 0, 0, 'test', 2, 15, 16, '9898989898', 'a@email.com', 4, '10 AM - 6 PM', 1, ''),
(9, 'dcsd', 1, 3, 2, 0, 0, 'sdcs', 12, 12, 23, '2323', 'a@email.com', 4, '10 AM - 6 PM', 8, ''),
(10, 'test9', 2, 1, 2, 0, 0, 'asxasx', 11, 89, 98, '2330', 'aamir@a2zheadsets.in', 4, '10 AM - 6 PM', 6, ''),
(11, 'rwfw', 2, 1, 1, 3, 6, '', 0, 0, 0, '2342', 'demo@email.com', 3, '10 AM - 6 PM', 6, '0'),
(12, 'asxas', 1, 1, 2, 0, 0, 'asa', 12, 12, 12, '12312', '1988.kalpesh@gmail.com', 3, '10 AM - 6 PM', 8, '0');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE IF NOT EXISTS `subcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `name`) VALUES
(1, 'men'),
(2, 'women'),
(3, 'kids');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `description` text,
  `eventinfo` int(11) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `pincode` int(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `accesslevel` int(11) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `facebookuserid` varchar(255) DEFAULT NULL,
  `newsletterstatus` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `showwebsite` varchar(255) DEFAULT NULL,
  `eventsheld` varchar(255) DEFAULT NULL,
  `topeventlocation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstname`, `lastname`, `password`, `email`, `website`, `description`, `eventinfo`, `contact`, `address`, `city`, `pincode`, `dob`, `accesslevel`, `timestamp`, `facebookuserid`, `newsletterstatus`, `status`, `logo`, `showwebsite`, `eventsheld`, `topeventlocation`) VALUES
(1, 'wohlig', '', 'a63526467438df9566c508027d9cb06b', 'wohlig@wohlig.com', '', '', 0, '233232', 'dadar', 'Mumbai', 322323, '1991-01-08', 1, '0000-00-00 00:00:00', '0', 0, 1, NULL, NULL, NULL, NULL),
(4, 'pratik', 'shah', '0cb2b62754dfd12b6ed0161d4b447df7', 'pratik@wohlig.com', '', '', 0, '8080209455', 'mulund', 'Mumbai', 400080, '1991-07-01', 1, '2014-05-12 06:52:44', '', 0, 1, NULL, NULL, NULL, NULL),
(5, 'wohlig123', 'tech', 'wohlig123', 'wohlig1@wohlig.com', 'www.wohlig.com', 'abc', 1234, '8989898989', 'abcdefg', 'mumbai', 200001, '1991-01-08', 1, '2014-05-12 06:52:44', '2', 2, 1, NULL, NULL, NULL, NULL),
(6, 'wohlig1', 'tech', 'a63526467438df9566c508027d9cb06b', 'wohlig2@wohlig.com', 'wohlig.com', 'abc', 1234, '8989898989', 'abcdefg', 'mumbai', 200001, '1991-01-08', 1, '2014-05-12 06:52:44', '2', 2, 1, NULL, NULL, NULL, NULL),
(7, 'fskdjl', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '', '', 0, '', '', '', 0, '0000-00-00', 0, '0000-00-00 00:00:00', '', 0, 0, NULL, NULL, NULL, NULL),
(8, '', '', 'e10adc3949ba59abbe56e057f20f883e', 'abc@gmail.com', '', '', 0, '', '', '', 0, '0000-00-00', 0, '0000-00-00 00:00:00', '', 0, 0, NULL, NULL, NULL, NULL),
(9, '', '', '5ca2aa845c8cd5ace6b016841f100d82', 'fsd@fas', '', '', 0, '', '', '', 0, '0000-00-00', 0, '0000-00-00 00:00:00', '', 0, 0, NULL, NULL, NULL, NULL),
(10, NULL, NULL, '5a5dc3936c05c32e61aa539e7ffb40c0', 'jfhskfaldjs@kdfhakjsdh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-12 11:44:08', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, NULL, NULL, 'd41d8cd98f00b204e9800998ecf8427e', 'kjhdkjf@dkfjks', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-12 11:45:41', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, NULL, NULL, '900150983cd24fb0d6963f7d28e17f72', 'jfaksdj@dkjfak', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-12 11:50:43', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, NULL, NULL, '47bce5c74f589f4867dbd57e9ca9f808', 'aaa@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-12 11:58:32', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'jagrutinew', '', '594f803b380a41396ed63dca39503542', 'aaaa@gmail.com', '', 'testinnew', 1, '', '', '', 0, '0000-00-00', 2, '0000-00-00 00:00:00', '', 0, 1, '', 'false', 'true', 'false'),
(15, NULL, NULL, '594f803b380a41396ed63dca39503542', 'aaaab@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-17 06:19:44', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, NULL, NULL, '0cc175b9c0f1b6a831c399e269772661', 'a@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-18 08:03:44', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'abc', '', '187ef4436122d1cc2f40dc2b92f0eba0', 'ab@gmail.com', '', '<h2 style="text-align: center;"><i><u>organiser abc</u></i></h2><br/>&#10;', 1, '', '', '', 0, '0000-00-00', 2, '2014-07-18 12:38:38', '', 0, 1, '', 'true', 'true', ''),
(18, 'aa', '', 'f30aa7a662c728b7407c54ae6bfd27d1', 'dd@dd.com', '', 'aaa', 0, '', '', '', 0, '0000-00-00', 2, '2014-07-18 13:07:08', '', 0, 1, '', '', '', ''),
(19, NULL, NULL, '0192023a7bbd73250516f069df18b500', 'admin@admin.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-19 08:56:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, NULL, NULL, 'fe01ce2a7fbac8fafaed7c982a04e229', 'demo@demo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-19 09:29:46', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, NULL, NULL, 'd16fb36f0911f878998c136191af705e', 'xyz@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-19 10:07:15', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, NULL, NULL, 'db8834197077287186e8c7524ca43d6f', 'vijaya@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-07-19 10:17:37', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE IF NOT EXISTS `userlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `onuser` int(11) NOT NULL,
  `fromuser` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `onuser`, `fromuser`, `description`, `timestamp`) VALUES
(1, 1, 1, 'User Address Edited', '2014-05-12 06:50:21'),
(2, 1, 1, 'User Details Edited', '2014-05-12 06:51:43'),
(3, 1, 1, 'User Details Edited', '2014-05-12 06:51:53'),
(4, 4, 1, 'User Created', '2014-05-12 06:52:44'),
(5, 4, 1, 'User Address Edited', '2014-05-12 12:31:48');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
