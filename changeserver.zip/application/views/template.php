
<?php 

echo $this->load->view('backend/includes/header');
echo $this->load->view('backend/includes/'.$page);
echo $this->load->view('backend/includes/footer');
